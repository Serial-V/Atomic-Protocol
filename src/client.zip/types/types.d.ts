
declare module 'zlib';