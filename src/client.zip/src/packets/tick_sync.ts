export interface TickSyncPacket {
    response_time: bigint;
}